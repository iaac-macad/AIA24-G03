import os
import tarfile

def make_tarfile(output_filename, source_dir):
    with tarfile.open(output_filename, "w:gz") as tar:
        tar.add(source_dir, arcname=os.path.basename(source_dir))

source_dir = r"C:\Users\libny\Streaming i Google Drive\Min enhet\AIA24_Studio_G03\Pix2Pix_Trial\direct-component-set"
output_filename = "archive.tar.gz"
make_tarfile(output_filename, source_dir)